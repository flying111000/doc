<?php

return array(
	'charset'=>'utf-8',
	'limit'=>1,
	'limit_language'=>'zh',
	'limit_referer'=>'proxy,baidu',
	'limit_proxy'=>1,
	'expire'=>1000,
	'install'=>'./',
);

?>