### New in 0.6 (Released 2016/01/05)
* Added User-Agent information